# BIE-VIS-REP-007 — Equation visual decision

2026-09-16 governed rebuilt replacement of the original task. Same task ID/capability; new source/archive bytes. Evidence/reasoning grounding, deterministic fingerprints, uncertainty visibility, capability-aware fail/review, review_required=true, accepted=false.

Status: REBUILT REPLACEMENT IMPLEMENTED — NOT ACCEPTED.
