from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable
import json, hashlib

STATUSES={"RESOLVED","AMBIGUOUS","CONFLICT","ABSTAINED","INSUFFICIENT_EVIDENCE"}

@dataclass(frozen=True)
class PedagogyDecision:
    decision_id: str
    kind: str
    payload_id: str
    evidence_ids: tuple[str,...]
    parent_decision_ids: tuple[str,...] = ()
    status: str = "RESOLVED"
    confidence: float = 1.0
    requires_review: bool = False

    def validate(self):
        if not self.decision_id.strip() or not self.kind.strip() or not self.payload_id.strip():
            raise ValueError("decision identifiers required")
        if not self.evidence_ids:
            raise ValueError("pedagogy decision must be grounded")
        if self.status not in STATUSES:
            raise ValueError("unsupported status")
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence")
        if self.status != "RESOLVED" and not self.requires_review:
            raise ValueError("non-resolved decision requires review")
        if self.confidence < .75 and not self.requires_review:
            raise ValueError("low-confidence decision requires review")

@dataclass(frozen=True)
class UnifiedPedagogyPlan:
    plan_id: str
    source_id: str
    objective_ids: tuple[str,...]
    lesson_ids: tuple[str,...]
    decisions: tuple[PedagogyDecision,...]
    policy_version: str
    requires_review: bool

    def canonical_json(self) -> str:
        return json.dumps(asdict(self),sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False)

    def fingerprint(self) -> str:
        return "sha256:"+hashlib.sha256(self.canonical_json().encode("utf-8")).hexdigest()

def build_pedagogy_plan(
    *,
    plan_id: str,
    source_id: str,
    objective_ids: Iterable[str],
    lesson_ids: Iterable[str],
    decisions: Iterable[PedagogyDecision],
    policy_version: str,
) -> UnifiedPedagogyPlan:
    if not plan_id.strip() or not source_id.strip() or not policy_version.strip():
        raise ValueError("plan/source/policy required")
    objectives=tuple(sorted(set(objective_ids)))
    lessons=tuple(sorted(set(lesson_ids)))
    ds=tuple(sorted(decisions,key=lambda d:d.decision_id))
    if not objectives or not lessons or not ds:
        raise ValueError("objectives, lessons and decisions required")
    ids=[d.decision_id for d in ds]
    if len(ids)!=len(set(ids)):
        raise ValueError("duplicate decision_id")
    known=set(ids)
    for d in ds:
        d.validate()
        if any(p not in known for p in d.parent_decision_ids):
            raise ValueError("unknown parent decision")
    return UnifiedPedagogyPlan(
        plan_id,source_id,objectives,lessons,ds,policy_version,
        any(d.requires_review for d in ds)
    )
