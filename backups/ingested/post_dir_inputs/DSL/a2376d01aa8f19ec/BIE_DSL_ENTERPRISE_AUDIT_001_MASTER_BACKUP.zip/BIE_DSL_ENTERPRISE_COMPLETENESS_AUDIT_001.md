# BIE Universal Scene IR — Enterprise Completeness Audit 001

## Audit basis

- Original DSL registry: **51 original tasks/capabilities**
- Original roadmap implementation: **51/51 IMPLEMENTED**
- Fresh cumulative regression: **258/258 PASS**
- Failures / errors / skips: **0/0/0**
- Current section state: **IMPLEMENTED WITH GAPS — NOT ACCEPTED**

The original registry is implemented, but the enterprise-completeness audit found **20 material MUST-HAVE gaps** that must be hardened before DSL can exit to COMP.

## Important concrete probes

- The canonical `SceneIR` currently does **not** integrate the major SPACE/TIME/INT/ACCESS/CAP structures as typed document fields.
- The machine JSON Schema keeps `elements` and `tracks` as shallow generic objects rather than the full typed contracts.
- The section has multiple validators, but no one canonical validation/orchestration gate.
- A mutation probe demonstrates that nested element payloads can be changed while the stored `ir_fingerprint` remains unchanged.
- No ANI→canonical-DSL adopter, DSL→COMP preflight handoff, real-book DSL harness, or DSL section-exit gate is present.

## Findings

| ID | Class | Priority | Finding |
|---|---|---|---|
| F01 | ARCHITECTURAL GAP | MUST-HAVE | Canonical SceneIR does not integrate SPACE/TIME/INT/ACCESS/CAP structures as typed top-level fields; many original capabilities remain detached helper contracts. |
| F02 | ARCHITECTURAL GAP | MUST-HAVE | Machine JSON Schema is shallow for elements/tracks and does not encode the typed element/action contracts implemented by the Python builders. |
| F03 | MISSING CAPABILITY | MUST-HAVE | No strict canonical JSON codec/loader/round-trip contract exists for dict/JSON → typed SceneIR → canonical JSON with unknown-field and canonicalization rules. |
| F04 | MISSING CAPABILITY | MUST-HAVE | No unified element/action registry normalizes all 18 element kinds and supported actions into one compiler-facing canonical representation. |
| F05 | INTEGRATION GAP | MUST-HAVE | No canonical ANI→DSL adopter consumes the implemented ANI SceneIR-ready handoff into the DSL contract. |
| F06 | INTEGRATION GAP | MUST-HAVE | Seven validators exist but there is no ordered section-level validation orchestrator producing one owned gate report. |
| F07 | INTEGRATION GAP | MUST-HAVE | Compiler capability registry is not resolved against each SceneIR element/track/profile as a document-level capability handshake. |
| F08 | INTEGRATION GAP | MUST-HAVE | Planned fallbacks are detached from canonical SceneIR and are not materialized/validated as part of the document handoff. |
| F09 | ARCHITECTURAL GAP | MUST-HAVE | Accessibility exists both inside elements and in a separate metadata contract without canonical merge/currentness, global reading-order, keyboard-focus and reduced-motion resolution. |
| F10 | MISSING CAPABILITY | MUST-HAVE | Spatial contracts detect some contradictions but do not solve layout constraints and emit a deterministic resolved-layout receipt. |
| F11 | MISSING CAPABILITY | MUST-HAVE | Temporal pieces are validated separately; there is no global lifetime/track/event/narration/interaction consistency resolver. |
| F12 | INTEGRATION GAP | MUST-HAVE | Interaction/state/simulation-control contracts are not embedded into SceneIR or globally cross-validated against elements, state paths and cues. |
| F13 | SOURCE/PROVENANCE GAP | MUST-HAVE | Trace validation checks only non-empty refs; it does not resolve refs to upstream evidence, verify currentness, confidence, or provenance existence. |
| F14 | RIGHTS/ASSET GAP | MUST-HAVE | Asset-backed elements lack one canonical asset contract requiring URI/hash/rights/currentness across image/video/model3d and compiler handoff. |
| F15 | MIGRATION GAP | MUST-HAVE | Legacy adapters emit SceneIR-like dicts but do not run the result through the canonical typed codec plus all validators and attach a full validation receipt. |
| F16 | REPRODUCIBILITY GAP | MUST-HAVE | Frozen dataclasses contain mutable nested payloads; audit probe can mutate element props while leaving the stored SceneIR fingerprint stale. |
| F17 | REPRODUCIBILITY GAP | MUST-HAVE | No section-level replay/currentness/invalidation record ties upstream ANI revision, DSL schema version, capability profile and output fingerprint together. |
| F18 | DOWNSTREAM INTEGRATION GAP | MUST-HAVE | No typed DSL→COMP preflight handoff proves compiler capability readiness without actually claiming compile/render success. |
| F19 | REAL-BOOK/EVALUATION GAP | MUST-HAVE | No independent multi-domain real-book SceneIR fixture/expected-output harness exists for DSL-level validation. |
| F20 | ENTERPRISE EXIT GAP | MUST-HAVE | No DSL section-exit gate combines regression, mutation, E2E, benchmark and acceptance-blocker evidence while keeping IMPLEMENTED distinct from ACCEPTED. |

## Authorized hardening roadmap — 20 tasks

- **H1 — `BIE-DSL-HARD-CONTRACT-001`**: unified typed SceneIR document contract
- **H1 — `BIE-DSL-HARD-CODEC-001`**: strict canonical JSON codec + round trip
- **H1 — `BIE-DSL-HARD-ANI-ADOPT-001`**: ANI SceneIR-ready handoff adopter
- **H1 — `BIE-DSL-HARD-REGISTRY-001`**: element/action registry and canonical normalization
- **H1 — `BIE-DSL-HARD-ORCH-001`**: section orchestrator and unified validation gate
- **H2 — `BIE-DSL-HARD-SPACE-SOLVE-001`**: deterministic spatial constraint solver + receipt
- **H2 — `BIE-DSL-HARD-TIME-SOLVE-001`**: global temporal/lifetime/cue resolver
- **H2 — `BIE-DSL-HARD-INTERACT-RESOLVE-001`**: interaction/state/simulation resolver
- **H2 — `BIE-DSL-HARD-ACCESS-MERGE-001`**: accessibility merge/read-order/focus/reduced-motion resolver
- **H2 — `BIE-DSL-HARD-CAP-RESOLVE-001`**: compiler capability handshake + fallback resolution
- **H3 — `BIE-DSL-HARD-PROV-001`**: upstream source/reasoning provenance resolver
- **H3 — `BIE-DSL-HARD-ASSET-001`**: canonical asset/hash/rights/currentness contract
- **H3 — `BIE-DSL-HARD-IMMUTABLE-001`**: deep immutable payload + fingerprint mutation guard
- **H3 — `BIE-DSL-HARD-MIG-VERIFY-001`**: migration full-pipeline validation receipt
- **H3 — `BIE-DSL-HARD-REPLAY-001`**: replay/currentness/invalidation record
- **H4 — `BIE-DSL-HARD-COMP-HANDOFF-001`**: typed compiler preflight handoff
- **H4 — `BIE-DSL-HARD-ACTUAL-E2E-001`**: ANI→DSL→validation→COMP-ready executable E2E
- **H4 — `BIE-DSL-HARD-REALBOOK-001`**: independent multi-domain real-book SceneIR harness
- **H4 — `BIE-DSL-HARD-BENCH-001`**: artifact-computed DSL benchmark
- **H4 — `BIE-DSL-HARD-SECTION-GATE-001`**: mutation/section-exit/acceptance gate

## Execution order

**H1 contract/integration → H2 spatial-temporal-interaction resolution → H3 trust/integrity → H4 compiler handoff/E2E/benchmark/section gate → re-audit.**

Do not move to COMP yet. The master workflow requires section hardening and re-audit after original planned tasks and before the next section.

## Acceptance truth boundary

Even after DSL implementation-scope exit, final product acceptance will still require downstream compiler execution, actual compile/render evidence, real-book E2E and product-level gates.

**Audit verdict: DSL = IMPLEMENTED WITH GAPS — NOT ACCEPTED.**
