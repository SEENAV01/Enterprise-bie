"""BIE package subset for Visual Intelligence atomic tasks."""
