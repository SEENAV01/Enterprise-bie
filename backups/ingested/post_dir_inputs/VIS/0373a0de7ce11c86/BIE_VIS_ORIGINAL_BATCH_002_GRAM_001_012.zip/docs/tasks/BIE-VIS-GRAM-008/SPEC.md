# BIE-VIS-GRAM-008 — history timeline grammar

## Baseline
Original BIE Enterprise v1.0 18-section master atomic task registry, VIS section (pages 10–11). This package implements the named L1 capability without changing the roadmap.

## Scope
- Adds deterministic, provider-neutral Visual Intelligence grammar behavior for **history timeline grammar**.
- All produced plans retain explicit evidence and reasoning references.
- Plans remain `review_required=true` and `accepted=false`; this component does not self-certify final visual correctness.
- Semantic constraints are machine-readable and fingerprints are deterministic for identical validated inputs.

## Dependencies
- BIE-VIS-GRAM-001

## Inputs and outputs
Inputs are structured, already-grounded domain data plus `evidence_refs` and `reasoning_refs`. Output is a deterministic grammar plan/registry artifact suitable for later VIS layout, Scene IR, animation and compiler layers.

## Required guarantees
- Reject blank/duplicate identifiers and malformed semantic inputs.
- Reject unbound evidence references at the grammar-plan boundary.
- Preserve uncertainty/semantic distinctions instead of inventing missing meaning.
- Remain source-first and IR-oriented: no raw-book→render shortcut.

## Explicit limitation
Timeline grammar preserves declared chronological keys/bounds and uncertainty; it does not infer dates or historical causality from raw sources.

## Acceptance state
IMPLEMENTED within this atomic component scope; **NOT ACCEPTED** as a final BIE capability. Real-book, downstream Scene IR/render and enterprise evaluation remain separate gates.
