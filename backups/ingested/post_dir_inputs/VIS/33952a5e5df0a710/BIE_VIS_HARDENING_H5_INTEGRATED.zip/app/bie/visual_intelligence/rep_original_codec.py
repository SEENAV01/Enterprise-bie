from __future__ import annotations
from dataclasses import dataclass,is_dataclass,asdict
from hashlib import sha256
from pathlib import Path
from typing import Any,Mapping
from .grammar_registry import VisualGrammarRegistry
class OriginalRepCodecError(ValueError):pass
class OriginalRepSourceUnavailableError(OriginalRepCodecError):pass
EXPECTED_REP_ARCHIVE_SHA256={'BIE_VIS_REP_001.zip': '9a818bff38a86235a2d40e039d35e3db24354da6da769e6183c881d2e233867d', 'BIE_VIS_REP_002.zip': '5280828dfb442a728d5504aec23f355d10acc99db8b05ff0e33920e6188f2c31', 'BIE_VIS_REP_003.zip': '59d3d6f7bc1fe7612600aaaefd9cf163eaeaa1b41a652546c2854eba6d7d7eca', 'BIE_VIS_REP_004.zip': '8393cb8886ed2d0e5d47b60bec1f9429f29f2e31e517eefde7a0941515ecdf75', 'BIE_VIS_REP_005.zip': '07eb7dfde8773122b524f63ebb028f8defc4461678cc6551e81da99b74c7bedb', 'BIE_VIS_REP_006.zip': '0c5ae1fe989bb108a5c8bb14d0d02996df82475cad8e8d3c45224a18da4dcb75', 'BIE_VIS_REP_007.zip': 'fbc13e70b2eab37e0ccece48d902ee10e56c4f8dd0524aa16bbe97e5e99de8c8', 'BIE_VIS_REP_008.zip': '87ece417e7075744b0f42523d3f83e8e17f68cf4f15f84e4565f1c9c7bdc5e71'}
@dataclass(frozen=True)
class RepVerification:
 verified:tuple[str,...];missing:tuple[str,...];mismatched:tuple[str,...];all_verified:bool
@dataclass(frozen=True)
class RepDecision:
 decision_id:str;revision:int;domain:str;representation:str;confidence:float;evidence_refs:tuple[str,...];reasoning_refs:tuple[str,...];required_capabilities:tuple[str,...];tags:tuple[str,...];current:bool;source_archives_verified:bool;review_required:bool=True;accepted:bool=False
@dataclass(frozen=True)
class GrammarView:
 grammar_id:str;version:str;domains:tuple[str,...];representations:tuple[str,...];capabilities:tuple[str,...];tags:tuple[str,...]
def verify_rep_archive_bytes(name,data):
 if name not in EXPECTED_REP_ARCHIVE_SHA256:raise OriginalRepCodecError('unknown REP archive')
 return sha256(data).hexdigest()==EXPECTED_REP_ARCHIVE_SHA256[name]
def verify_rep_archive_directory(directory):
 root=Path(directory);v=[];m=[];bad=[]
 for n,h in sorted(EXPECTED_REP_ARCHIVE_SHA256.items()):
  p=root/n
  if not p.exists():m.append(n)
  elif sha256(p.read_bytes()).hexdigest()==h:v.append(n)
  else:bad.append(n)
 return RepVerification(tuple(v),tuple(m),tuple(bad),len(v)==8 and not m and not bad)
def mp(x):
 if isinstance(x,Mapping):return dict(x)
 if is_dataclass(x):return asdict(x)
 if hasattr(x,'to_dict'):return dict(x.to_dict())
 if hasattr(x,'__dict__'):return dict(x.__dict__)
 raise OriginalRepCodecError('REP output not decodable')
def decode_rep_decision(raw,source_archives_verified,require_exact_source=True):
 if require_exact_source and not source_archives_verified:raise OriginalRepSourceUnavailableError('REP source archives not byte-verified')
 d=mp(raw);req=('decision_id','domain','representation','confidence','evidence_refs','reasoning_refs')
 miss=[k for k in req if k not in d]
 if miss:raise OriginalRepCodecError('missing REP fields:'+str(miss))
 c=float(d['confidence'])
 if not 0<=c<=1:raise OriginalRepCodecError('confidence outside [0,1]')
 ev=tuple(d['evidence_refs']);rr=tuple(d['reasoning_refs'])
 if not ev or not rr:raise OriginalRepCodecError('REP lineage missing')
 return RepDecision(str(d['decision_id']),int(d.get('revision',1)),str(d['domain']),str(d['representation']),c,ev,rr,tuple(d.get('required_capabilities',())),tuple(d.get('tags',())),bool(d.get('current',True)),bool(source_archives_verified))
def adapt_original_grammar_registry(registry:VisualGrammarRegistry):
 return tuple(GrammarView(g.grammar_id,g.version,tuple(g.domains),tuple(g.representations),tuple(sorted(set(g.allowed_primitives)|set(g.required_roles))),tuple(g.tags)) for g in registry.list())
