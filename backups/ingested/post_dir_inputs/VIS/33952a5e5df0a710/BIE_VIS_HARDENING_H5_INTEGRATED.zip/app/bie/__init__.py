"""BIE package fragment for enterprise hardening evidence."""
