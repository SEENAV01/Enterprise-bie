# BIE Visual Intelligence — Full Re-Audit 002

## Verdict

**VIS is NOT YET implementation-scope complete.**

The 51 original VIS roadmap tasks and the 20 first-audit hardening tasks are present as implemented component work, but the re-audit found **5 remaining MUST-HAVE integration/evidence gaps**. The correct action is **one corrective H5 batch of 5 atomic tasks**, followed by a final re-audit. Do not move to ANI yet.

## Regression evidence reproduced in this re-audit

- Fresh executable overlay: **GRAM + LAYOUT + ASSET + TEXT + ACCESS + QA + H1/H2/H3/H4 = 535/535 tests PASS**.
- Failures/errors/skips: **0/0/0**.
- Conflicting non-`__init__` file overlays: **0**.
- Python modules in the inspected overlay: **69**.
- REP-001..008 remains separately evidenced as **125 tests PASS** in the preserved REP result, but the REP source ZIPs were not available in this active runtime.
- Therefore family-level passing evidence is **660 tests**, but **660/660 is not claimed as one integrated run**.

## What H1–H4 successfully closed

The hardening materially improved the section: unified versioned VisualPlan/currentness, DIR-style adoption boundary, orchestration skeleton, representation/grammar arbitration, executable grammar policies, semantic grammar→layout projection, active constraint solving, typography measurement, narration timing, continuity ledger, uncertainty/abstention, closed-loop asset state, accessibility gates, element-level traceability, replay/invalidation, downstream capability handoff, complexity budgeting, E2E gate contracts, fixture schema and dataset-style benchmark machinery.

Those capabilities should be preserved; H5 is corrective wiring, not a redesign.

## Remaining findings

### VIS-REAUDIT-F01 — Generic orchestrator is not wired to the actual original VIS families
**Severity:** MUST_HAVE / INTEGRATION_GAP

**Evidence:** `visual_orchestrator.py` imports ['director_handoff_adoption', 'visual_plan_contract'] and imports 0 original GRAM/LAYOUT/ASSET/TEXT/ACCESS/QA executors. Runtime stage functions are registered by callers.

**Why it matters:** The section has an orchestration skeleton, but no canonical production executor proves that the original 51-task implementations are the code actually executed.

### VIS-REAUDIT-F02 — DIR adoption uses a parallel local handoff model rather than an adapter over the canonical completed DIR contract
**Severity:** MUST_HAVE / CANONICAL_ADOPTION_GAP

**Evidence:** `director_handoff_adoption.py` defines local `VisualIntent`, `TimingCue`, and `DirectorHandoff` classes and has no import from the canonical `bie.director` namespace.

**Why it matters:** A supplied object can satisfy the VIS-local contract without proving compatibility with the canonical DIR artifacts/currentness records.

### VIS-REAUDIT-F03 — REP→GRAM hardening does not consume the actual original REP output or original grammar registry directly
**Severity:** MUST_HAVE / ADAPTER_GAP

**Evidence:** `representation_grammar_arbitration.py` defines local `RepDecision`/`Grammar` descriptors and has no import from original REP modules or `grammar_registry.py`.

**Why it matters:** Arbitration logic is implemented, but production compatibility with the actual original REP/GRAM contracts is not established.

### VIS-REAUDIT-F04 — H4 E2E is an evidence gate, not an execution of the real VIS stages
**Severity:** MUST_HAVE / E2E_GAP

**Evidence:** `run_visual_e2e()` accepts pre-built `stage_evidence`, trace/access/asset/handoff/performance objects; it does not call `VisualOrchestrator` or original family modules.

**Why it matters:** The H4 task does not yet satisfy the audit closure condition of executing a canonical structured DIR output through all actual VIS families into a downstream-ready handoff.

### VIS-REAUDIT-F05 — REP source is not present in the active re-audit runtime, so a single all-original+hardening regression cannot be demonstrated
**Severity:** MUST_HAVE / REGRESSION_EVIDENCE_GAP

**Evidence:** Fresh local overlay of GRAM through QA plus H1-H4 hardening passes 535/535. REP-001..008 has separate preserved evidence of 125 passing tests, but its source bundle was not available in the active runtime.

**Why it matters:** Current family-level evidence totals 660 passing tests, but it is not one executable all-VIS suite.

## Authorized H5 corrective batch

### BIE-VIS-HARD-CANONICAL-DIR-CODEC-001 — Canonical DIR→VIS contract adapter
**Closes:** VIS-REAUDIT-F02

**Scope:** Decode/verify the actual canonical DIR visual/timing/currentness artifacts into the VIS handoff contract without duplicating DIR semantics; reject stale/unknown schema revisions.

### BIE-VIS-HARD-REP-CODEC-001 — Original REP output and grammar-registry adapters
**Closes:** VIS-REAUDIT-F03, VIS-REAUDIT-F05

**Scope:** Recover/include REP-001..008 production source, adapt actual REP outputs and the original VisualGrammar registry to the hardened arbitration contract, and preserve exact IDs/evidence/confidence.

### BIE-VIS-HARD-FAMILY-WIRING-001 — Canonical original-family executors
**Closes:** VIS-REAUDIT-F01

**Scope:** Implement production executor adapters for REP, GRAM, LAYOUT, ASSET, TEXT, ACCESS and QA using the original modules; register them in one canonical VisualOrchestrator factory.

### BIE-VIS-HARD-ACTUAL-E2E-001 — Actual canonical VIS execution E2E
**Closes:** VIS-REAUDIT-F04

**Scope:** Run a canonical DIR artifact through the real registered family executors, produce VisualPlan→ANI/Scene-IR handoff, exercise blockers/currentness/trace/access/assets/performance, and reject raw-source bypass.

### BIE-VIS-HARD-SECTION-GATE-001 — All-VIS regression, mutation and section-exit gate
**Closes:** VIS-REAUDIT-F01, VIS-REAUDIT-F02, VIS-REAUDIT-F03, VIS-REAUDIT-F04, VIS-REAUDIT-F05

**Scope:** Run original REP+GRAM+LAYOUT+ASSET+TEXT+ACCESS+QA plus all hardening in one fresh-extraction suite; add negative mutation tests and produce a section-exit manifest ready for canonical GitHub integration.

## Real-book / rendered-media truth boundary

The REALBOOK harness and benchmark infrastructure are useful implementation. The bundled six-domain reference fixtures remain synthetic/non-acceptance fixtures. That is **not** treated as a reason to redesign VIS again; independently sourced textbook cases, live-provider quality, actual ANI/Scene-IR/compiler/render/frame inspection remain **acceptance evidence blockers** and later downstream/product gates.

## Exit rule after H5

VIS may be marked **IMPLEMENTATION-SCOPE COMPLETE — NOT ACCEPTED** only if the next re-audit demonstrates:

1. canonical DIR artifacts are decoded through a real adapter, not a parallel stand-in schema;
2. original REP source is present and exercised;
3. original REP/GRAM/LAYOUT/ASSET/TEXT/ACCESS/QA modules are the executors registered in the production VIS path;
4. actual E2E invokes that path rather than consuming pre-built stage receipts;
5. one fresh-extraction all-VIS suite passes with mutation/failure tests and a section-exit manifest.

Only after that should section-end canonical GitHub integration occur, followed by ANI.
