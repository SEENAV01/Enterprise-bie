# BIE Visual Intelligence — Enterprise Completeness Audit 001

## Decision

**VIS original roadmap: COMPLETE (51/51 original tasks).**

**VIS enterprise implementation scope: NOT COMPLETE.**

**Recommendation: CONTINUE HARDENING VIS. Do not move to ANI yet.**

This review follows the canonical section rule in the uploaded *BIE Enterprise v1.0 Original 18-Section Master Atomic Task Registry*: finish original tasks, perform an enterprise-completeness audit, convert material MUST-HAVE gaps into traceable hardening tasks, implement/re-audit, then move to the next section.

## Evidence reviewed

- Original registry VIS scope: REP-001..008, GRAM-001..012, LAYOUT-001..010, ASSET-001..007, TEXT-001..005, ACCESS-001..004, QA-001..005 = **51 original tasks**.
- REP batch result: **125 tests PASS** in its documented component scope; result explicitly says no raw-PDF ingestion, semantic proof, live simulation/model execution or media rendering is claimed.
- GRAM batch: **152 tests PASS**.
- LAYOUT batch: **86 tests PASS**.
- ASSET batch: **49 tests PASS**.
- TEXT batch: **45 tests PASS**.
- ACCESS batch: **34 tests PASS**.
- QA batch: **35 tests PASS**.
- Family-level total evidence = **526 passing tests**.
- Fresh local overlay of the currently available post-REP sources (GRAM+LAYOUT+ASSET+TEXT+ACCESS+QA): **401/401 tests PASS** across 50 Python source files.
- The REP source bundle was not available in this runtime for a single all-VIS overlay, so **526/526 is NOT claimed as one integrated suite**.
- Final DIR continuity evidence says DIR is implementation-scope complete, canonical, and its typed visual/animation preview/currentness contracts are ready for downstream stage adoption.

## What is already strong

1. **Grounding discipline:** grammar/layout/asset/text/access/QA components consistently retain source/evidence/reasoning identifiers.
2. **Determinism:** stable fingerprints, canonical payloads and fresh-extraction tests are used heavily.
3. **Fail-closed behavior:** many invalid geometries, unsupported grammars, missing rights, unsafe text placement and QA blockers are rejected/escalated.
4. **Domain coverage:** executable planners exist for vectors, fields, process flows, cellular biology, molecular chemistry, maps, timelines, causal networks, mathematical graphs, geometry and data/charts.
5. **Accessibility baseline:** contrast, readable size, color-independent encoding and alt-description intent exist.
6. **QA baseline:** semantic/layout/clutter/asset QA plus a hard-floor aggregate benchmark exist.
7. **Correct acceptance boundary:** outputs remain review-required / accepted=false.

## Material findings

### F01 — CRITICAL INTEGRATION GAP: no section-level VIS execution path

Static inspection of the available post-REP implementation found **zero cross-family imports** across GRAM, LAYOUT, ASSET, TEXT, ACCESS and QA. Each family works in isolation. There is no current Visual Intelligence orchestrator proving:

`REP → GRAM → LAYOUT → ASSET/TEXT/ACCESS → QA → downstream handoff`

This is a real implementation gap, not an evaluation-only gap.

### F02 — UPSTREAM ADOPTION GAP

Final DIR is canonical and provides typed visual intent/timing/currentness/review outputs, but the current VIS batches are standalone component packages. VIS must adopt the actual DIR contract and invalidation/currentness semantics rather than rely on manually authored family inputs.

### F03 — CONTRACT FRAGMENTATION

The current implementation has separate grammar, layout, asset, text, access and QA contracts, but no unified versioned `VisualPlan` carrying the entire source/reasoning/revision/capability lineage. This makes replay, invalidation, ANI/DSL handoff and section-wide auditability incomplete.

### F04 — GRAMMAR SEMANTICS ARE PARTLY DOCUMENTARY

The grammar registry carries `semantic_constraints` as strings. Domain planners implement useful checks, but the generic grammar contract does not execute those constraint statements. A caller can therefore create plans that satisfy primitive/role/evidence structure without uniform machine-executed semantic policy.

### F05 — LAYOUT SOLVER IS PARTIAL

The current solver actively applies safe-area, subtitle-safe and collision handling, then **evaluates** the remaining semantic constraints. It does not generally solve alignment, containment, minimum gap/size and other supported constraints. This is below the intended meaning of a top-notch semantic layout solver.

### F06 — TYPOGRAPHY IS NOT MEASURED

Text/equation modules make deterministic decisions, but there is no shared measurable text/equation metrics contract feeding actual bounding-box needs into the layout solver. Long strings, equations, multilingual scripts and font metrics can therefore be structurally valid but still overflow at downstream render time.

### F07 — NARRATION/VISUAL SYNC IS NOT CONSUMED END-TO-END

DIR owns narration-to-visual/equation/graph/simulation sync contracts. VIS currently has focus/layout logic but no section-level execution that binds it to those exact timing/revision cues.

### F08 — CROSS-SCENE CONTINUITY IS MISSING

No current module owns a lesson-wide visual identity ledger for entity colors, symbols, notation, coordinate frames, style tokens and representation continuity. Individually valid scenes can therefore drift visually across a lesson.

### F09 — UNCERTAINTY IS NOT PROPAGATED AS A SECTION POLICY

Some domain grammars preserve uncertainty and some components have confidence values, but there is no section-wide policy ensuring uncertain/conflicting upstream facts cannot become visually certain. `review_required=true` is too coarse to replace explicit uncertainty/abstention semantics.

### F10 — ASSET LIFECYCLE IS REQUEST-LEVEL, NOT CLOSED-LOOP

Generated/external asset modules intentionally create request contracts only. This is honest, but VIS still lacks the lifecycle state machine that ties source reuse, generation/external requests, post-generation grounding, rights/attribution, hashes, quality, fallback and unresolved-URI blocking together.

### F11 — ACCESSIBILITY IS MOSTLY STANDALONE

ACCESS checks exist, but there is no cross-family planning path proving accessibility participates in grammar/layout/text/asset decisions before handoff. A top-notch planner should solve or explicitly escalate accessibility, not merely report it afterward.

### F12 — QA TRACEABILITY IS TOO COARSE

Current semantic QA is principally set/coverage based, while asset/layout QA use their own IDs. There is no unified element-level trace matrix proving each visible claim/element/relation/text/asset has retained source and reasoning support through every stage.

### F13 — REPLAY / INVALIDATION / CURRENTNESS IS MISSING IN VIS

DIR hardening established durable revisions/currentness and stale-consumer rejection. VIS does not yet show equivalent stage adoption. Exact replay and upstream change invalidation are required before canonical enterprise integration.

### F14 — DOWNSTREAM CONTRACT IS INCOMPLETE

ANI and Scene IR are the next owners, but VIS currently lacks one stable typed handoff describing primitives, 2D/3D requirements, assets, accessibility, timing/focus, fallbacks and unsupported capabilities.

### F15 — COMPLEXITY BUDGET IS MISSING

VIS can detect clutter after a plan exists, but it lacks an explicit pre-handoff visual complexity/render-cost budget tied to target capability. This is important for long lessons, 3D/simulation decisions and reliable compiler execution.

### F16 — SECTION E2E/REGRESSION IS MISSING

The family-level suites are strong, and the available post-REP overlay passes 401/401. But there is no single current integrated execution that runs canonical DIR-like input through every VIS stage and tests mutation/failure ownership. REP source also needs to be included in the final all-VIS gate.

### F17 — REAL-SOURCE MULTI-DOMAIN EVIDENCE IS MISSING

The current component tests are deterministic unit/contract evidence. They do not establish that real textbook-derived physics/math/bio/chem/history/geography/data cases select and preserve the right visual semantics.

### F18 — VIS BENCHMARK IS AGGREGATION-ONLY

QA-005 has useful weights/hard floors, but it aggregates caller-supplied component QA results. It is not yet a dataset-backed benchmark with independent expected outputs, adversarial mutations, calibration and explicit `NOT_RUN` empirical states.

## Section status

- Original task coverage: **COMPLETE**
- Component implementation quality: **STRONG**
- Section integration: **INCOMPLETE**
- Enterprise hardening: **REQUIRED**
- Real-book empirical validation: **INCOMPLETE**
- Actual rendered-frame validation: **DOWNSTREAM ACCEPTANCE BLOCKER**
- Product acceptance: **FALSE**

## Authorized hardening roadmap

The following **20 MUST-HAVE hardening tasks** are justified directly by the findings above. They are additions to the original 51-task baseline, not replacements.


### BIE-VIS-HARD-CONTRACT-001 — Unified versioned VisualPlan contract

**Priority:** MUST-HAVE

**Scope:** Create one section-level immutable contract joining representation, grammar, layout, assets, text, accessibility, QA, upstream IDs/revisions and deterministic fingerprints.

**Closure evidence:** A VisualPlan round-trips deterministically; every child object has source/reasoning lineage; incompatible schema/policy versions fail closed.

### BIE-VIS-HARD-DIR-ADOPT-001 — Canonical DIR handoff/currentness adoption

**Priority:** MUST-HAVE

**Scope:** Consume the completed canonical DIR visual-intent/timing/currentness/review handoff instead of authored VIS-only inputs; propagate invalidation and review state.

**Closure evidence:** Stale/invalidated DIR input cannot yield a current VIS plan; exact source/revision/narration bindings are verified.

### BIE-VIS-HARD-ORCH-001 — Visual Intelligence section orchestrator

**Priority:** MUST-HAVE

**Scope:** Execute the existing stages in dependency order REP→GRAM→LAYOUT→ASSET/TEXT/ACCESS→QA under one bounded provider-neutral stage, without recreating upstream logic.

**Closure evidence:** One registered/typed VIS execution path produces a persisted VisualPlan and failure evidence; no parallel raw-book→VIS shortcut exists.

### BIE-VIS-HARD-REP-GRAM-001 — Representation-to-grammar arbitration

**Priority:** MUST-HAVE

**Scope:** Bind REP decisions to the versioned grammar registry with ambiguity detection, capability matching and abstention/review rather than manual grammar selection.

**Closure evidence:** Every selected representation resolves to exactly one compatible grammar or explicit REVIEW/UNSUPPORTED; evidence and confidence remain bound.

### BIE-VIS-HARD-GRAM-EXEC-001 — Executable semantic grammar constraints

**Priority:** MUST-HAVE

**Scope:** Turn grammar semantic constraints from descriptive strings into machine-executable validators/policies while preserving domain-specific checks.

**Closure evidence:** Mutations violating scale/causality/CRS/uncertainty/chemistry/geometry/data semantics are blocked by executable validators, not documentation only.

### BIE-VIS-HARD-GRAM-LAYOUT-001 — Grammar-to-layout semantic projection

**Priority:** MUST-HAVE

**Scope:** Translate grammar elements/relations/roles into layout nodes/constraints while preserving IDs, grouping, hierarchy, source anchors and semantic relations.

**Closure evidence:** Round-trip trace proves every required grammar element reaches layout or an explicit supported omission/fallback decision.

### BIE-VIS-HARD-LAYOUT-SOLVER-001 — Constraint-solving hardening

**Priority:** MUST-HAVE

**Scope:** Upgrade the current solver so supported constraints such as containment, alignment, min-gap and min-size are actively solved/optimized, not merely evaluated after safe-area/subtitle/collision passes.

**Closure evidence:** Feasible cases satisfy all hard constraints deterministically; infeasible cases return an explainable unsat core/fallback path without dropping required semantics.

### BIE-VIS-HARD-TYPO-METRICS-001 — Text/equation measurement and overflow model

**Priority:** MUST-HAVE

**Scope:** Add deterministic typography measurement contracts for wrapping, equations, labels and annotations so layout uses measured bounds rather than requested boxes only.

**Closure evidence:** Long text, multilingual labels and equations either fit measured bounds or deterministically reflow/escalate; no silent overflow.

### BIE-VIS-HARD-NARR-SYNC-001 — Narration/timing-aware visual planning

**Priority:** MUST-HAVE

**Scope:** Adopt DIR narration-to-visual/equation/graph/simulation sync cues and timing windows in focus, reveal ownership and visual availability decisions.

**Closure evidence:** VIS plan binds visual emphasis/focus to exact narration spans and rejects stale/mismatched timing revisions.

### BIE-VIS-HARD-CONTINUITY-001 — Cross-scene visual identity and continuity ledger

**Priority:** MUST-HAVE

**Scope:** Keep entity colors, symbols, notation, coordinate frames, styles and representation identity stable across lesson scenes unless a justified transition is declared.

**Closure evidence:** Repeated entities/concepts use consistent tokens across scenes; intentional changes are explicit, source-bound and reviewable.

### BIE-VIS-HARD-UNCERTAINTY-001 — Uncertainty/confidence/abstention propagation

**Priority:** MUST-HAVE

**Scope:** Carry upstream uncertainty and representation ambiguity through grammar, asset, text, layout and QA instead of relying mainly on a generic review_required flag.

**Closure evidence:** Low-confidence or conflicting inputs cannot become visually certain; uncertainty is visible or the plan abstains/escalates with reasons.

### BIE-VIS-HARD-ASSET-LIFECYCLE-001 — Asset lifecycle, grounding and rights state machine

**Priority:** MUST-HAVE

**Scope:** Orchestrate source reuse→generation request→external request→fallback with hashes, provenance, rights/attribution, generation-grounding check and unresolved-URI failure state.

**Closure evidence:** No production-ready plan can contain unresolved URI, unknown required rights, or ungrounded generated asset; lifecycle is replayable.

### BIE-VIS-HARD-ACCESS-INTEGRATION-001 — Accessibility as planning constraints

**Priority:** MUST-HAVE

**Scope:** Integrate contrast, readable size, color-independent encoding and alt intent into grammar/layout/text/asset planning, rather than leaving ACCESS as isolated post-hoc checks.

**Closure evidence:** Accessibility violations participate in solver/fallback decisions and survive into downstream handoff metadata.

### BIE-VIS-HARD-QA-TRACE-001 — Element-level semantic/provenance trace matrix

**Priority:** MUST-HAVE

**Scope:** Replace coarse set-level QA alone with a trace matrix from source/evidence/reasoning → representation → grammar element/relation → layout/text/asset → QA.

**Closure evidence:** Unsupported visual claims/elements, lost required concepts and orphaned evidence are detected at element level with exact IDs.

### BIE-VIS-HARD-REPLAY-001 — Versioned replay, invalidation and currentness

**Priority:** MUST-HAVE

**Scope:** Bind VisualPlan to upstream artifact revisions, grammar/policy versions, target capability profile and output fingerprints; reuse existing infrastructure/DIR currentness semantics.

**Closure evidence:** Changed source/DIR/policy invalidates descendants; exact replay reproduces fingerprints; stale child artifacts cannot publish as current.

### BIE-VIS-HARD-CAP-HANDOFF-001 — ANI/Scene-IR capability handoff

**Priority:** MUST-HAVE

**Scope:** Emit a typed downstream contract declaring visual primitives, 2D/3D needs, assets, accessibility, timing/focus intent, unsupported capabilities and planned fallbacks.

**Closure evidence:** ANI/DSL can consume VIS without reverse-engineering internal modules; unsupported capability fails explicitly rather than degrading silently.

### BIE-VIS-HARD-PERF-001 — Visual complexity/render-cost budget

**Priority:** MUST-HAVE

**Scope:** Estimate semantic element count, asset weight, 2D/3D complexity, text density and target capability budget before downstream compilation.

**Closure evidence:** Over-budget scenes trigger deterministic simplification/split/review while preserving required learning semantics.

### BIE-VIS-HARD-E2E-001 — Section-level end-to-end execution and regression

**Priority:** MUST-HAVE

**Scope:** Execute canonical structured DIR outputs through all VIS families into a downstream-ready VisualPlan; run all original and hardening tests together.

**Closure evidence:** One extracted integrated bundle executes all VIS stages; all original tests remain green; negative mutations fail at the owning gate.

### BIE-VIS-HARD-REALBOOK-001 — Real-source multi-domain planning fixtures

**Priority:** MUST-HAVE

**Scope:** Build independently specified textbook-derived cases for physics, math, biology, chemistry, geography/history and data/charts using exact source lineage.

**Closure evidence:** Cases exercise real structure/ambiguity/notation/assets and report expected decisions separately from implementation-generated expectations.

### BIE-VIS-HARD-BENCH-001 — Calibrated multi-domain VIS benchmark

**Priority:** MUST-HAVE

**Scope:** Turn QA-005 from aggregation-only into a versioned benchmark harness with independent expectations, adversarial mutations, hard floors and truthful NOT_RUN states for unavailable empirical checks.

**Closure evidence:** Benchmark scores are dataset-backed, reproducible and cannot pass merely because callers supplied already-good component scores.

## Recommended execution batches

### Hardening Batch H1 — section spine
1. BIE-VIS-HARD-CONTRACT-001
2. BIE-VIS-HARD-DIR-ADOPT-001
3. BIE-VIS-HARD-ORCH-001
4. BIE-VIS-HARD-REP-GRAM-001
5. BIE-VIS-HARD-GRAM-EXEC-001

### Hardening Batch H2 — semantic realization
6. BIE-VIS-HARD-GRAM-LAYOUT-001
7. BIE-VIS-HARD-LAYOUT-SOLVER-001
8. BIE-VIS-HARD-TYPO-METRICS-001
9. BIE-VIS-HARD-NARR-SYNC-001
10. BIE-VIS-HARD-CONTINUITY-001

### Hardening Batch H3 — trust and lifecycle
11. BIE-VIS-HARD-UNCERTAINTY-001
12. BIE-VIS-HARD-ASSET-LIFECYCLE-001
13. BIE-VIS-HARD-ACCESS-INTEGRATION-001
14. BIE-VIS-HARD-QA-TRACE-001
15. BIE-VIS-HARD-REPLAY-001

### Hardening Batch H4 — downstream readiness and proof
16. BIE-VIS-HARD-CAP-HANDOFF-001
17. BIE-VIS-HARD-PERF-001
18. BIE-VIS-HARD-E2E-001
19. BIE-VIS-HARD-REALBOOK-001
20. BIE-VIS-HARD-BENCH-001

## SHOULD-HAVE backlog, not section-exit blockers unless product scope makes them mandatory

- multilingual/RTL typography and locale-specific label layout beyond the base measurement contract;
- property-based/fuzz testing for grammar/layout adversarial inputs;
- richer perceptual/style aesthetics and brand theming;
- local visual auto-repair policies that belong primarily to the later enterprise QA/repair section.

## Acceptance blockers that should NOT be falsely pulled into VIS implementation scope

Even after these 20 tasks, VIS may correctly be **IMPLEMENTATION-SCOPE COMPLETE — NOT ACCEPTED** until downstream systems exist and provide:
- actual Scene IR/ANI/COMP execution;
- real rendered frames/video;
- frame-level semantic/readability/overflow inspection;
- live/generated asset empirical grounding quality;
- multi-domain real-book E2E and independent expert evidence.

## Final audit recommendation

**CONTINUE HARDENING THIS SECTION.**

Do not move to ANI yet. Execute H1→H4, run a full section regression/re-audit, and only then decide whether VIS is implementation-scope complete. Section-end canonical GitHub integration should follow the re-audit under the established preservation/readback workflow.
