"""BIE package fragment."""
