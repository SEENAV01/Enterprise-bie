"""BIE package fragment for atomic task evidence."""
