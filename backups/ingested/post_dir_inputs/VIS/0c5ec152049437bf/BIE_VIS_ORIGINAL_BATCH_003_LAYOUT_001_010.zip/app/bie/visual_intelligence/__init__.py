"""Visual Intelligence atomic-task implementation fragment."""
