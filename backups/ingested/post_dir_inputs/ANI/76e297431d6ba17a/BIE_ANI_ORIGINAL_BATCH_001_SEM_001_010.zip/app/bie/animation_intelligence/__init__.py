"""Animation Intelligence integrated SEM layer."""
