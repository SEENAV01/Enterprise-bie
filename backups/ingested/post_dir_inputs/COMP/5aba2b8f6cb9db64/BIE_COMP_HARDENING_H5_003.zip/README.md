# BIE-COMP-H5-003

Ordered delta, NOT standalone. Requires exact H4 integrated workspace and H5 tasks ['BIE-COMP-H5-001', 'BIE-COMP-H5-002']. Extract this ZIP and run `python APPLY_DELTA.py --base /absolute/previous-stage --output /absolute/new-stage`. Never overlay manually onto an unknown tree. Test: `PYTHONPATH=app:. python -m unittest tests.compiler.test_comp_h5_003 -v`. Parent checkpoint metadata remains until H5-005; this intermediate stage is not a production release. Cumulative integrated ZIP is separately supplied. Accepted=false.
