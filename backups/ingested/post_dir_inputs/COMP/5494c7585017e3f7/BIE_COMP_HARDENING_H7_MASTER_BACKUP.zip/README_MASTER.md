# COMP H7 Master Backup

Use the separate cumulative INTEGRATED.zip as the current DSL + COMP workspace. All eight atomic packages are ordered source deltas from the exact H6 integrated baseline, not standalone apps. All eight must be restored before running task tests.

The evidence ZIP contains diagnostic browser images, real isolated workers/audio tests and failed plus corrected development runs. The actual renderer remains blocked. See the result, re-audit and continuation: whole-section completion and product acceptance are false. No previous Master is embedded. No GitHub write occurred.

SHA256SUMS.txt covers each payload. Local hashes prove byte identity, not publisher authenticity. The external FINAL_VERIFICATION.json adds this Master's hash without a circular self-hash.
