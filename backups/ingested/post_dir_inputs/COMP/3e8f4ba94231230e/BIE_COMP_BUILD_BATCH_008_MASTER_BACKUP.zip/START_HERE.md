# BIE COMP Batch 008 — start here

Open `BIE_COMP_ORIGINAL_BATCH_008_RESULT.md` and the continuation JSON first.
The authoritative local continuation workspace is
`BIE_COMP_ORIGINAL_BATCH_008_BUILD_007_010.zip`. Extract it to a new empty directory.
The atomic ZIPs carry the same executable source with task-specific evidence; do not
layer different generations blindly. All four atomic sources match this cumulative
workspace byte-for-byte. Their fresh-extraction tests passed, as did 751 cumulative tests.

The prior Batch 007 master is an immutable lineage backup, not the working checkpoint.
No previous Python source/test file was changed: 272 preserved. All 293 original
workspace members remain accounted for, with old root metadata archived in `lineage/`.

Implemented here: BIE-COMP-BUILD-007..010. Implementation/local tests passed; actual
Remotion rendering is NOT RUN because npm registry lookup failed with EAI_AGAIN.
Retained FFmpeg patterns are explicitly labelled injected-renderer test evidence.
Do not promote them to real Remotion, real-book, learning-quality or product acceptance.

Next original task IDs: BIE-COMP-QA-001, QA-002, QA-003, QA-004, QA-005. Their original
capabilities are documented in the cumulative `docs/ORIGINAL_NEXT_TASKS.json`.
Keep the real-render blocker open. Finish original tasks, audit capabilities, add
justified hardening, rerun regression and re-audit; do not automatically exit COMP.
GitHub has not been modified or integrated by this batch. COMP remains IN_PROGRESS.

`SHA256SUMS.txt` covers every other member of this master. Its own archive hash is
provided separately outside the ZIP to avoid a self-reference. Every returned receipt
continues to carry `accepted=false`.
