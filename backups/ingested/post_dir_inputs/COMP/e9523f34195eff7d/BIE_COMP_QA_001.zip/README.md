# BIE-COMP-QA-001 — atomic implementation bundle

Includes shared compiler/Scene IR dependencies and immutable QA fixture corpus so this atomic task can be tested independently. Dependencies bundled here are not additional newly completed tasks.

From this root run:

```bash
PYTHONPATH=app python -m unittest tests.compiler.test_comp_qa_001 -v
```

Expected task suite: 29 tests. Read TASK_RESULT.json and docs/SPEC.md. The cumulative workspace has 921 tests; this atomic bundle intentionally contains only its own suite. Node and a real TypeScript installation are required for actual-tool tests.

Status: implementation/local tests only, NOT ACCEPTED. Full pinned Remotion compile/render and real-book acceptance remain open. The capability audit identifies inherited semantic defects that these QA guards detect, not fix. No GitHub write has been performed.
