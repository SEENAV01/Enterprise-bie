# Current H9 release

Use the separate cumulative Integrated ZIP for the entire current DSL + COMP workspace. Atomic ZIPs are ordered source deltas requiring the exact H8 integrated workspace; all five must be restored before task tests. No previous Master Backup is embedded. The current Integrated ZIP inside this master is byte-identical to the separate download. Heavy current diagnostics are in EVIDENCE.zip, not added again to the active source workspace. Final outer-archive SHA256 verification is an external sidecar to avoid self-hash recursion.
