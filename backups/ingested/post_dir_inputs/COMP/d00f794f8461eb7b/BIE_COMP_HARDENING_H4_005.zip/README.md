# BIE COMP H4-005 — ordered source delta

This is NOT a standalone application. Start from the exact H3 integrated source archive (BIE_COMP_HARDENING_H3_SOURCE.zip, SHA256 `ee6f0b94a472e13bf5c2e3fc80b9372440f26fca12ad5605baee6ef56245f27d`). Apply tasks 001 through 005 in order.

After extracting this delta, run:

```bash
python APPLY_DELTA.py --base /absolute/previous-workspace --output /absolute/new-workspace
cd /absolute/new-workspace
PYTHONPATH=app:. python -m unittest tests.compiler.test_comp_h4_005 -v
```

The helper checks the entire previous source tree, validates payload hashes, restores into a new directory and does not modify its base. Python bytecode/cache files are ignored. Package hashes ensure consistency, not authenticity. Install governed test/runtime dependencies separately; no fonts, browser or node_modules are included.

Expected atomic count: 16. Full repaired source is independently available in BIE_COMP_HARDENING_H4_INTEGRATED.zip; no delta application is needed when using it. Restored source is not a product-acceptance claim.
