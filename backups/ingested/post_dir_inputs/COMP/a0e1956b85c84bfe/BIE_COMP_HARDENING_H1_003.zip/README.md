# BIE-COMP-H1-003

Explicit dimensional vector projection. Independently testable source/dependency closure.

`PYTHONPATH=app:. python -m unittest tests.compiler.test_comp_h1_003 -v`

Read docs/SPEC.md and docs/COMP_H1_SPEC.md. No real Remotion/render/product acceptance. Full app/shared dependencies included; do not overlay it blindly onto a later batch. Use cumulative source for continuing the entire workspace.
