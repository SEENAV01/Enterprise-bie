# H10 restore guide

For the current source, extract BIE_COMP_HARDENING_H10_INTEGRATED.zip into a new empty directory. It contains the cumulative DSL + COMP workspace, not the whole canonical BIE repository. Verify WORKSPACE_SHA256SUMS.txt before use.

Atomic ZIPs are optional ordered source deltas. They need the EXACT H9 integrated baseline SHA256 295628ff2a5d076117a6e87aad66536962a32f7beb28c43673390fe2017e5d4e. Extract each package; run its APPLY_DELTA.py --base PREVIOUS_DIRECTORY --output NEW_DIRECTORY, in order 001, 002, 003, 004. Restore all FOUR before running tests; intermediate stages are not standalone applications. Existing base files are not changed.

Run PYTHONPATH=app:. PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v from the final workspace. Compiler, math/raster and Node/TypeScript tooling dependencies remain required. Real rendering additionally requires the pinned React/Remotion toolchain and approved kernel profile; no fallback is implicit.

The Master includes the same integrated ZIP bytes as the separate download, current deltas/reports/evidence only. Old Masters are not recursively embedded. Prior bytes and manifests are preserved in integrated lineage. PACKAGE_VERIFICATION.json records the already executed checks before master assembly; the external FINAL_VERIFICATION.json also binds this final Master SHA256. No GitHub commit or product acceptance is implied.
