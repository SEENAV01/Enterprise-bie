# COMP QA-001..005 — Batch 009 specification

Date: 2026-09-18. Parent: the user's Batch 008 cumulative workspace.
Status: IMPLEMENTED AND LOCALLY TESTED; section IN PROGRESS; product NOT ACCEPTED.

## Purpose and architectural boundary

This is an additive compiler QA layer, not a replacement compiler, director, Scene IR, or production orchestrator. It imports the existing Scene IR codec, capability resolver, element/animation emitters, React/project generators, deterministic code generator, BUILD lint/static checks, bounded process runner and artifact identity utilities. None of the 288 inherited Python files was changed. The original registry tail in `docs/ORIGINAL_NEXT_TASKS.json` supplies the five task identifiers; no QA-006 is invented.

`qa_scene_compile.py` is an explicit QA integration adapter. It invokes original emitters and carries their original emitted TSX bytes into a generated project. It requires explicit fixture layout and records unconsumed contracts rather than guessing a lesson plan. It is not evidence that the complete production book-to-video path is integrated. Its fixture target is 640x360, 24 frames per second, two seconds; these are test settings, not BIE product limits.

## QA-001: compile diagnostics mapping

Implementation: `app/bie/compiler/compile_diagnostics_mapping.py` and `qa_common.py`.

Generate a content-bound origin map for generated files, elements and animation tracks. Origins retain source references and reasoning references from the supplied Scene IR. File paths, line ranges, hashes, identifiers, duplicates and overlapping spans are checked. The map is an explicit generated-source-to-IR map, not a claim to implement JavaScript VLQ source maps or recover page coordinates absent from inputs.

Parse actual TypeScript non-pretty diagnostics, including global messages, Windows/colon paths, continuation lines and ANSI text. Preserve severity, original compiler code and global/unmapped status. Deduplicate in a deterministic order. A failed process with no parsed error becomes an explicit process failure. Join compatible existing TypeScript, lint, static-analysis and render receipts without promoting a failed/unmapped result to a successful mapped one.

Real local `tsc` tests produce an actual type error and verify its mapping. Missing locations stay unknown; source pages, quotations and reviewer approvals are never fabricated. Relative build-receipt paths must share the chosen mapping root; arbitrary cross-workspace path rewriting is not promised.

## QA-002: capability fallback QA

Implementation: `app/bie/compiler/capability_fallback_qa.py`.

A fallback plan alone is insufficient. Validate real booleans, known element/action/profile combinations, source and reasoning preservation, accessibility obligations, and a hash-bound application witness for the actual emitted files. Reject malformed identifiers, duplicates, unsupported or missing actions, unresolved required capabilities, orphan evidence, changed output and unknown emitter warnings. Optional missing capabilities can produce explicit warnings; illustrative substitutes cannot satisfy required semantic capabilities by silently downgrading them.

Reviewer evidence is an explicit external reference bound to the scene and output; the code does not invent reviewer approval or claim that reference identity proves teaching quality. Static emitted-semantic checks detect known losses in the inherited emitters, including chart kind/sign, raw typesetting, text-as-JSX execution, lost vector components, nonexecuted simulation, map/projection problems and invalid model edges. These guards detect/block defects; they do not fix the inherited emitter implementations.

Application witnessing is technical binding, not image-based proof of visual or pedagogical equivalence. Production entry points must adopt these guards and then pass real downstream acceptance before a required fallback can be considered usable.

## QA-003: deterministic output test

Implementation: `app/bie/compiler/deterministic_output_qa.py`; worker: `scripts/qa_compile_worker.py`.

Bind source-tree identity to input, compiler, dependency, adapter and seed identities. Compare exact file paths, bytes, sizes and hashes. Detect added/deleted/changed files, altered context, empty trees, tampered hashes, missing repeats and generator failures. Directory snapshots reject symlinks and enforce file/byte budgets. Trusted workers run in fresh directories through the existing bounded process runner with timeout and failure receipts.

The delivered benchmark repeats every case in three independent Python processes using PYTHONHASHSEED values 1, 73 and 997, in addition to in-process repeats. Generated source, codegen manifests, source maps and source-contract records are compared. This proves source-byte repeatability for these fixed inputs and current tools only. It is not MP4 bitstream determinism, frame determinism, a cross-platform guarantee, or a sandbox for arbitrary user generators.

## QA-004: generated-code regression

Implementation: `app/bie/compiler/generated_code_regression.py` and `qa_support/typescript_source_probe.cjs`.

Compare actual source snapshots against explicit, immutable initial goldens. Validate baseline identity and reject automatic rebaselining, content/hash tampering, context drift and unexpected output. Run the real installed TypeScript parser/AST on exact bound source. Inspect static imports, local source coverage and known unsafe/nondeterministic patterns (including unseeded random, clocks, timers, dynamic execution, network calls, suppression comments and selected environment/Node access). Existing BUILD lint and static analysis remain in the gate.

The AST policy is finite and deliberately not an exhaustive JavaScript security sandbox. It does not execute generated JavaScript. Actual process tests exercise real TypeScript; negative policy fixtures are inspected, not executed as Remotion scenes.

Full generated-project typechecking is a separate gate. Verify actual installed declared dependencies, strict compiler settings and source hashes; use real `tsc --listFilesOnly` to reject excluded source, then actual `tsc --project ... --noEmit --pretty false`. Missing dependencies, disabled checks or uncovered files produce BLOCKED/FAIL, not a synthetic compile success. Explicit source-only mode never sets `compile_verified` or product acceptance.

Local TypeScript is 5.8.3; the unchanged generated project requests 5.9.3, React 19.0.0 and Remotion 4.0.506. Parser and self-contained compiler tests therefore do not certify that pinned generated dependency tree. Tool drift is recorded in `validation/comp_qa_009/ENVIRONMENT.json`.

## Initial golden source policy

The 19 goldens were recorded once in this batch for its new synthetic technical corpus, using the explicit fixture-author command in `scripts/build_qa009_fixture_corpus.py`. The `approval_ref` points to this policy section and represents test-author baseline provenance, not a user/expert approval or an earlier historical acceptance. Each golden says INITIAL_GOLDEN_SOURCE_NOT_PRODUCT_APPROVAL and accepted=false.

Regression never calls the authoring script or overwrites a golden. Known-defective negative outputs are frozen only so the detector can be regressed. They are NOT the desired product behavior. A future intentional defect fix must add positive behavior/render evidence and undergo a reviewed, versioned expectation/baseline update. Passing a negative fixture means rejection worked, not the defective lesson was accepted.

## QA-005: multi-domain compile benchmark

Implementation: `app/bie/compiler/multidomain_compile_benchmark.py`; command: `scripts/run_compiler_qa.py`.

The frozen corpus has 19 unique fixtures in 10 domains, all explicitly synthetic, with source/fixture identity binding. Ten positive source cases and nine explicit negative cases exercise real inherited generation, exact repeated output, real TypeScript AST parsing, source contracts, fallback checks, diagnostic mapping and golden regression. A negative case must match the exact expected error-code set; additional unexpected failures cannot be hidden as an expected rejection.

Each case writes source, manifests, origins, diagnostic/QA receipts, snapshot evidence and measured source-generation time/size. Recorded timing describes local source generation only—not rendering, complete compiler throughput, cost or subject-level learning quality. Budget checks are technical test budgets, not production service-level guarantees.

The final run matched 19/19 source expectations: ten positive passes and nine detected-defect rejections. All 57 independent generator processes matched. Zero full generated-project compiles were verified, because all case projects lack the required installed dependencies. The command exited 2, intentionally not a full-compile PASS. No Remotion rendering, real book parsing or educational validation occurred in this benchmark.

## Reproduction

From the extracted cumulative source root:

```bash
PYTHONPATH=app python -m unittest discover -s tests -v
python scripts/run_compiler_qa.py --output /tmp/bie-comp-qa-fresh-run
```

Use a new nonexistent/empty output location for each benchmark. The script performs no npm install, network request or canonical-repository write. It requires Python, Node and a real TypeScript installation for the corresponding actual-tool tests. Legacy render tests also need the same FFmpeg/ffprobe tools used in Batch 008. Missing tools must not be reported as verified execution.

CLI exit codes: 0 means full positive compile gates verified; 1 means a source expectation failed; 2 means source expectations match but full compile evidence is incomplete. Even exit 0 would not establish real rendering or product acceptance. The separately available inherited render runner requires real installed Remotion dependencies and actual output inspection.

## Evidence and acceptance

751/751 inherited tests rerun. 154 new atomic tests plus 16 integration tests; total 921/921, no failures/errors/skips. See raw logs and TEST_SUMMARY.json, rather than treating these numbers as enterprise-wide or additive to unrelated section totals.

The npm registry was probed and returned EAI_AGAIN. Pinned project typecheck, real CLI discovery, real smoke/full render, frame inspection, real-book E2E, game execution and educational acceptance remain open. The separate capability audit includes actual implementation defects, not merely environmental blockers. COMP cannot exit on these results. No GitHub write or integration was performed.

A preliminary benchmark invocation was interrupted before completion and is explicitly marked RUN_ABORTED.json. It is not certification evidence. The complete final run is `validation/comp_qa_009/benchmark_final/BENCHMARK_RESULT.json`, with process exit recorded separately.

## Primary documentation consulted

- Remotion deterministic randomness: https://www.remotion.dev/docs/random
- TypeScript CLI and project/listFilesOnly options: https://www.typescriptlang.org/docs/handbook/compiler-options.html
- TypeScript compiler configuration: https://www.typescriptlang.org/tsconfig/
- Remotion render CLI: https://www.remotion.dev/docs/cli/render

These describe tool APIs; they do not constitute evidence that BIE rendered or passed acceptance. Executed local evidence is stored separately.
