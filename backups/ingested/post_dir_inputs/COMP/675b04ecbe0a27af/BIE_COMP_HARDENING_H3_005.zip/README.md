# BIE-COMP-H3-005

Atomic source and dependency closure. This is part of H3, not a separate replacement product.

Run from this directory:
```bash
PYTHONPATH=app:. python -m unittest tests.compiler.test_comp_h3_005 -v
```

25 atomic tests passed in the included actual log. Required Python/tool versions are described in requirements-comp-h3.txt and the cumulative README. Real React/Remotion and real-book acceptance are not claimed.

This ZIP contains its targeted module and local dependencies; the cumulative ZIP/master contains the full 1409-test suite, browser harness, benchmark, lineage and full evidence. Do not treat this atomic archive as the whole BIE repository.
