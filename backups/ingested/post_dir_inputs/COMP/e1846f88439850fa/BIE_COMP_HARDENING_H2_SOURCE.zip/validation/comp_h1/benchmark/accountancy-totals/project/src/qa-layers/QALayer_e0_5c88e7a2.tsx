import React from "react";
import {Chart_e0_5c88e7a2} from "../elements/Chart_e0_5c88e7a2";
export const QALayer_e0_5c88e7a2: React.FC = () => {
  return <div style={{"height": "40.0%", "left": "5.0%", "position": "absolute", "top": "5.0%", "width": "90.0%"}}><Chart_e0_5c88e7a2 /></div>;
};
