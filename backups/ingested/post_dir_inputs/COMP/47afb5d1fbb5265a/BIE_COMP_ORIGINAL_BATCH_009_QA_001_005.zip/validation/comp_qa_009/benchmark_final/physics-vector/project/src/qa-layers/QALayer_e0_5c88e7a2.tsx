import React from "react";
import {Vector_e0_5c88e7a2} from "../elements/Vector_e0_5c88e7a2";
export const QALayer_e0_5c88e7a2: React.FC = () => {
  return <div style={{"height": "40.0%", "left": "5.0%", "position": "absolute", "top": "5.0%", "width": "90.0%"}}><Vector_e0_5c88e7a2 /></div>;
};
