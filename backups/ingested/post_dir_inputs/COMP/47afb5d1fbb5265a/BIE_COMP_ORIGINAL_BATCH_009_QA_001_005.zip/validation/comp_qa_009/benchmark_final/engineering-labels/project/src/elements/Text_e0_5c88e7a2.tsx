import React from "react";
import {Interactive} from "remotion";

export const Text_e0_5c88e7a2: React.FC = () => {
  return (
    <Interactive.Div
      name={"e0"}
      role="text"
      aria-label={"Synthetic text compiler fixture"}
      data-role={"body"}
    >
      तकनीकी परीक्षण • engineering fixture
    </Interactive.Div>
  );
};
