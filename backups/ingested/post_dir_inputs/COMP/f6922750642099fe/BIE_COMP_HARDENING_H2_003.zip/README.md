# BIE-COMP-H2-003

Frame-driven visual motion. Run `PYTHONPATH=app:. python -m unittest tests.compiler.test_comp_h2_003 -v` from this root.

This task bundle includes the shared H2 compiler core and frozen fixtures needed by the targeted tests. It is not the cumulative full-regression workspace. Use H2_SOURCE.zip for all tests and lineage. Tests require the recorded external Python/Node/TypeScript tools; see requirements and docs/SPEC.md.

No full pinned-project compile, actual Remotion render, section exit or product acceptance is claimed.
