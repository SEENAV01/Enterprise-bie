#!/usr/bin/env python3
"""Restore one ordered H5 delta into a NEW directory. Never modifies its base.

After extracting the delta ZIP, run:
  python APPLY_DELTA.py --base /absolute/previous-workspace --output /absolute/new-workspace

Hashes bind exact bytes; they are not a digital signature or external trust proof.
Python bytecode/cache files are ignored and not copied. All other base files must
match the expected tree, so wrong order or an unrelated workspace fails closed.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, tempfile
from pathlib import Path, PurePosixPath


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative(value: str) -> Path:
    if not isinstance(value, str) or not value or '\\' in value:
        raise ValueError('INVALID_RELATIVE_PATH')
    p=PurePosixPath(value)
    if p.is_absolute() or '..' in p.parts or '.' in p.parts or p.as_posix()!=value:
        raise ValueError('INVALID_RELATIVE_PATH')
    return Path(*p.parts)


def no_symlink(p: Path) -> None:
    if p.is_symlink() or any(x.is_symlink() for x in p.parents):
        raise ValueError('SYMLINK_REJECTED')


def tree(root: Path) -> dict[str,str]:
    no_symlink(root)
    if not root.is_dir():raise ValueError('BASE_NOT_DIRECTORY')
    result={}
    for folder,dirs,files in os.walk(root,followlinks=False):
        for name in dirs:
            if (Path(folder)/name).is_symlink():raise ValueError('SYMLINK_REJECTED')
        dirs[:]=[x for x in dirs if x!='__pycache__']
        for name in files:
            p=Path(folder)/name
            if p.is_symlink():raise ValueError('SYMLINK_REJECTED')
            if p.suffix in ('.pyc','.pyo'):continue
            result[p.relative_to(root).as_posix()]=sha(p.read_bytes())
    return result


def tree_id(files: dict[str,str]) -> str:
    return sha(json.dumps(sorted(files.items()),ensure_ascii=False,separators=(',',':')).encode('utf-8'))


def apply(base: Path, output: Path, package: Path) -> dict:
    base=base.absolute(); output=output.absolute(); package=package.absolute()
    for p in [base,output,package]:no_symlink(p)
    if base==output or base in output.parents or output in base.parents:
        raise ValueError('BASE_OUTPUT_MUST_BE_SEPARATE')
    if output.exists():raise ValueError('OUTPUT_ALREADY_EXISTS')
    manifest=json.loads((package/'DELTA_MANIFEST.json').read_text())
    if manifest.get('schema_version')!='bie.ordered-source-delta.v1':raise ValueError('UNKNOWN_DELTA_SCHEMA')
    before=tree(base)
    if tree_id(before)!=manifest['required_tree_sha256']:raise ValueError('BASE_TREE_MISMATCH_WRONG_ORDER_OR_CHANGED_FILES')
    expected=dict(before); seen=set();data={}
    for row in manifest['payload']:
        rel=safe_relative(row['path']); key=rel.as_posix()
        if key in seen:raise ValueError('DUPLICATE_PAYLOAD_PATH')
        seen.add(key);p=package/'payload'/rel;no_symlink(p)
        if not p.is_file():raise ValueError('PAYLOAD_MISSING')
        value=p.read_bytes()
        if sha(value)!=row['sha256']:raise ValueError('PAYLOAD_HASH_MISMATCH')
        if before.get(key)!=row['previous_sha256']:raise ValueError('FILE_PRECONDITION_MISMATCH')
        data[key]=value;expected[key]=row['sha256']
    if tree_id(expected)!=manifest['result_tree_sha256']:raise ValueError('RESULT_TREE_MANIFEST_MISMATCH')
    if tree(package/'payload')!={k:sha(v) for k,v in data.items()}:raise ValueError('UNDECLARED_PAYLOAD_FILE')
    output.parent.mkdir(parents=True,exist_ok=True)
    temp=Path(tempfile.mkdtemp(prefix='.bie-h5-restore-',dir=output.parent))
    staged=temp/'workspace'
    try:
        shutil.copytree(base,staged,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
        for name,value in data.items():
            p=staged/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value)
        if tree_id(tree(staged))!=manifest['result_tree_sha256']:raise ValueError('RESTORED_TREE_MISMATCH')
        os.rename(staged,output)
    finally:
        shutil.rmtree(temp,ignore_errors=True)
    return {'task_id':manifest['task_id'],'status':'RESTORED_SOURCE_NOT_EXECUTION_ACCEPTANCE','base_unchanged':True,'output':str(output),'result_tree_sha256':manifest['result_tree_sha256'],'files_applied':len(data),'accepted':False}


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    try:result=apply(a.base,a.output,Path(__file__).parent)
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print(json.dumps({'status':'RESTORE_BLOCKED','error':str(exc),'accepted':False}));return 2
    print(json.dumps(result,indent=2));return 0

if __name__=='__main__':sys.exit(main())
