# BIE-COMP-H6-003: ordered source delta, not standalone

Extract this package. Run `python APPLY_DELTA.py --base /absolute/previous-workspace --output /absolute/new-workspace`. H6-001 requires exact H5 integrated source; later deltas require preceding H6 stages. Base is never modified. Caches/bytecode are ignored, but other bytes must match exactly.

IMPORTANT: all FIVE deltas must be restored before running any task suite. Cross-task producer/consumer adoption is delivered in H6-005. Intermediate stages are source assembly steps, not working or accepted releases. For a directly usable cumulative workspace use BIE_COMP_HARDENING_H6_INTEGRATED.zip.

Verification command after full restore: `PYTHONPATH=app:. PYTHONDONTWRITEBYTECODE=1 python -m unittest tests.compiler.test_comp_h6_003 -v` (20 tests).

See SPEC and current batch report for exact evidence bounds. No GitHub commit, real Remotion render, audio playback or product acceptance is implied by this package.
