def lesson_boundaries(concepts,max_load=2):
 out=[]; cur=[]; load=0; topic=None
 for cid,tp,cost in concepts:
  if cur and (tp!=topic or load+cost>max_load): out.append(tuple(cur)); cur=[]; load=0
  cur.append(cid); load+=cost; topic=tp
 if cur: out.append(tuple(cur))
 return tuple(out)
