from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
import hashlib, json

STATES={"BRIDGE","REMEDIATE","PRACTICE","STANDARD","ACCELERATE","MASTERY_CHECK","MASTERED"}

@dataclass(frozen=True)
class AdaptiveState:
    learner_id: str
    concept_id: str
    state: str
    mastery: float
    version: int
    evidence_ids: tuple[str,...]

@dataclass(frozen=True)
class AdaptiveTransition:
    from_state: str
    to_state: str
    reason: str
    evidence_ids: tuple[str,...]

def next_state(
    current: AdaptiveState,
    *,
    prerequisite_ready: bool,
    misconception_detected: bool,
    transfer_passed: bool,
    new_mastery: float,
    evidence_ids: Iterable[str],
) -> tuple[AdaptiveState,AdaptiveTransition]:
    if current.state not in STATES or not 0<=current.mastery<=1 or current.version<0:
        raise ValueError("invalid current state")
    if not 0<=new_mastery<=1:
        raise ValueError("new_mastery")
    ev=tuple(sorted(set(evidence_ids)))
    if not ev:
        raise ValueError("transition evidence required")
    if not prerequisite_ready:
        target,reason="BRIDGE","prerequisites not ready"
    elif misconception_detected:
        target,reason="REMEDIATE","misconception detected"
    elif new_mastery>=.9 and transfer_passed:
        target,reason="MASTERED","high mastery plus transfer"
    elif new_mastery>=.85:
        target,reason="ACCELERATE","high mastery"
    elif new_mastery>=.7:
        target,reason="MASTERY_CHECK","approaching mastery"
    elif new_mastery>=.5:
        target,reason="PRACTICE","developing mastery"
    else:
        target,reason="STANDARD","needs instruction"
    nxt=AdaptiveState(current.learner_id,current.concept_id,target,new_mastery,current.version+1,ev)
    return nxt,AdaptiveTransition(current.state,target,reason,ev)

def state_fingerprint(state: AdaptiveState) -> str:
    payload=json.dumps(state.__dict__,sort_keys=True,separators=(",",":"),allow_nan=False)
    return "sha256:"+hashlib.sha256(payload.encode()).hexdigest()
