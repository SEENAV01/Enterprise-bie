from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

@dataclass(frozen=True)
class PedagogyLineage:
    artifact_id: str
    source_evidence_ids: tuple[str,...]
    reasoning_parent_ids: tuple[str,...]
    prerequisite_parent_ids: tuple[str,...] = ()
    math_parent_ids: tuple[str,...] = ()
    assumptions: tuple[str,...] = ()
    confidence: float = 1.0
    requires_review: bool = False

def build_lineage(
    artifact_id: str,
    *,
    source_evidence_ids: Iterable[str],
    reasoning_parent_ids: Iterable[str],
    prerequisite_parent_ids: Iterable[str]=(),
    math_parent_ids: Iterable[str]=(),
    assumptions: Iterable[str]=(),
    confidence: float=1.0,
    requires_review: bool=False,
) -> PedagogyLineage:
    if not artifact_id.strip():
        raise ValueError("artifact_id")
    ev=tuple(sorted(set(source_evidence_ids)))
    re=tuple(sorted(set(reasoning_parent_ids)))
    if not ev or not re:
        raise ValueError("source evidence and reasoning lineage required")
    if not 0<=confidence<=1:
        raise ValueError("confidence")
    assumptions=tuple(a for a in assumptions if str(a).strip())
    if (confidence<.75 or assumptions) and not requires_review:
        raise ValueError("uncertain lineage requires review")
    return PedagogyLineage(
        artifact_id,ev,re,tuple(sorted(set(prerequisite_parent_ids))),
        tuple(sorted(set(math_parent_ids))),assumptions,confidence,requires_review
    )

def validate_lineage_graph(lineages: Iterable[PedagogyLineage]) -> tuple[str,...]:
    ls=tuple(lineages)
    ids={x.artifact_id for x in ls}
    if len(ids)!=len(ls):
        raise ValueError("duplicate artifact_id")
    # Parent IDs may be external upstream IDs, but internal cycles are forbidden.
    adj={x.artifact_id:[p for p in x.reasoning_parent_ids if p in ids] for x in ls}
    visiting=set(); done=set(); cycles=set()
    def dfs(n):
        if n in visiting:
            cycles.add(n); return
        if n in done: return
        visiting.add(n)
        for p in adj[n]: dfs(p)
        visiting.remove(n); done.add(n)
    for n in sorted(ids): dfs(n)
    return tuple(sorted(cycles))
