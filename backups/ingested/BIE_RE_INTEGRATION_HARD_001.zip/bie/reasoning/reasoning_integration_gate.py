from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Mapping
import hashlib, json

@dataclass(frozen=True)
class ReasoningStageEvidence:
    stage: str
    artifact_id: str
    evidence_ids: tuple[str,...] = ()
    parent_artifact_ids: tuple[str,...] = ()
    requires_review: bool = False

@dataclass(frozen=True)
class ReasoningIntegrationReport:
    passed: bool
    missing_required_stages: tuple[str,...]
    dangling_parent_ids: tuple[str,...]
    ungrounded_stage_artifacts: tuple[str,...]
    review_artifacts: tuple[str,...]
    fingerprint: str

_REQUIRED=("evidence","decision","graph","uncertainty","qa")

def reasoning_integration_gate(
    artifacts: Iterable[ReasoningStageEvidence],
    *,
    required_stages: Iterable[str] = _REQUIRED,
) -> ReasoningIntegrationReport:
    artifacts=tuple(artifacts)
    ids=[a.artifact_id for a in artifacts]
    if len(ids)!=len(set(ids)):
        raise ValueError("duplicate artifact_id")
    required=tuple(required_stages)
    present={a.stage for a in artifacts}
    missing=tuple(sorted(set(required)-present))
    known=set(ids)
    dangling=tuple(sorted({
        p for a in artifacts for p in a.parent_artifact_ids if p not in known
    }))
    # Evidence-stage artifacts are roots and may legitimately have no evidence_ids.
    ungrounded=tuple(sorted(
        a.artifact_id for a in artifacts
        if a.stage != "evidence" and not a.evidence_ids
    ))
    reviews=tuple(sorted(a.artifact_id for a in artifacts if a.requires_review))
    payload=[{
        "stage":a.stage,
        "artifact_id":a.artifact_id,
        "evidence_ids":sorted(a.evidence_ids),
        "parent_artifact_ids":sorted(a.parent_artifact_ids),
        "requires_review":a.requires_review
    } for a in sorted(artifacts,key=lambda x:(x.stage,x.artifact_id))]
    fingerprint="sha256:"+hashlib.sha256(
        json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    ).hexdigest()
    passed=not missing and not dangling and not ungrounded and not reviews
    return ReasoningIntegrationReport(passed,missing,dangling,ungrounded,reviews,fingerprint)
